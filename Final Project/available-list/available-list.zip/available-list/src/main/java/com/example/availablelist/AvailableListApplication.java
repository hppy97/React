package com.example.availablelist;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AvailableListApplication {

	public static void main(String[] args) {
		SpringApplication.run(AvailableListApplication.class, args);
	}

}
