package com.example.availablelist;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AvailableListApplicationTests {

	@Test
	void contextLoads() {
	}

}
