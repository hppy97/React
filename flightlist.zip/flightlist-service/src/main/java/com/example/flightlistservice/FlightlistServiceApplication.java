package com.example.flightlistservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FlightlistServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(FlightlistServiceApplication.class, args);
	}

}
