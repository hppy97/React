package com.example.flightlistservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FlightlistServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
